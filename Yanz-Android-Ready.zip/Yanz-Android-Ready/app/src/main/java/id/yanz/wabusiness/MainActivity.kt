package id.yanz.wabusiness

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = 0xFFF4F7FB.toInt()
    private val navy = 0xFF14243A.toInt()
    private val green = 0xFF16865B.toInt()
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun base(title: String, subtitle: String) {
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
            setBackgroundColor(bg)
        }
        scroll.addView(content)
        setContentView(scroll)
        text("YANZ  •  WA BUSINESS", 13, green, true)
        text(title, 27, navy, true)
        text(subtitle, 14, 0xFF627187.toInt(), false)
        space(18)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) {
        content.addView(TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(5))
        })
    }

    private fun space(h: Int) {
        content.addView(android.view.View(this), LinearLayout.LayoutParams(1, dp(h)))
    }

    private fun card(title: String, body: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(0xFFFFFFFF.toInt())
            elevation = dp(2).toFloat()
        }
        box.addView(TextView(this).apply {
            text = title; textSize = 16f; setTextColor(navy)
            setTypeface(typeface, Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = body; textSize = 13f; setTextColor(0xFF627187.toInt())
            setPadding(0, dp(7), 0, 0)
        })
        content.addView(box, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(12)
        })
    }

    private fun action(label: String, onClick: () -> Unit) {
        content.addView(Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun showHome() {
        base("Dashboard", "Panel demo Yanz untuk pengelolaan pesan WhatsApp resmi.")
        card("Status koneksi", "Belum terhubung ke WhatsApp Cloud API. Hubungkan hanya setelah konfigurasi Meta resmi selesai.")
        card("Pelanggan", "0 pelanggan demo\nGunakan hanya kontak yang memberi persetujuan menerima pesan.")
        card("Kampanye", "0 kampanye aktif\nPesan promosi wajib memakai template yang disetujui jika diwajibkan WhatsApp.")
        card("Perlindungan", "Persetujuan pelanggan • Daftar berhenti • Pembatasan pengiriman • Catatan aktivitas")
        action("Kelola pelanggan (demo)") { showCustomers() }
        action("Aturan pengiriman") { showRules() }
        action("Tentang aplikasi") { showAbout() }
    }

    private fun showCustomers() {
        base("Pelanggan", "Contoh tampilan daftar pelanggan. Belum menyimpan atau mengirim data.")
        card("Belum ada pelanggan", "Versi ini hanya prototipe antarmuka. Fitur penyimpanan aman akan dihubungkan ke backend setelah siap.")
        action("Kembali ke dashboard") { showHome() }
    }

    private fun showRules() {
        base("Aturan pengiriman", "Pemeriksaan kepatuhan sebelum fitur pengiriman diaktifkan.")
        card("Persetujuan", "Kirim hanya kepada orang yang telah memberi izin menerima pesan.")
        card("Berhenti berlangganan", "Hormati permintaan STOP/berhenti dan jangan kirim pesan promosi lagi.")
        card("Batas pengiriman", "Patuhi batas dan kualitas akun yang ditetapkan WhatsApp. Tidak ada jaminan bebas pemblokiran.")
        card("Template resmi", "Gunakan template yang disetujui dan API resmi Meta.")
        action("Kembali ke dashboard") { showHome() }
    }

    private fun showAbout() {
        base("Tentang Yanz", "Prototipe Android • versi 1.0.0")
        card("Catatan", "Aplikasi ini belum terhubung ke backend atau WhatsApp Cloud API. Tidak ada pesan yang dikirim dari versi demo ini.")
        action("Kembali ke dashboard") { showHome() }
    }
}

YANZ WA BUSINESS — PROTOTIPE ANDROID

Isi paket:
- Aplikasi Android native sederhana dengan dashboard demo.
- Workflow GitHub Actions untuk membangun APK debug.
- Target Android 15 (compile/target SDK 35), minimum Android 6.0.

PENTING:
Versi ini adalah prototipe antarmuka. Belum ada backend, database pelanggan,
login produksi, WhatsApp Cloud API, atau pengiriman pesan. Jangan masukkan
nomor pelanggan, token Meta, atau kata sandi ke aplikasi demo ini.

CARA BUILD APK TANPA KOMPUTER (melalui GitHub Actions):
1. Unggah folder Yanz-Android-Ready beserta folder .github ke repositori GitHub.
2. Pastikan workflow berada di .github/workflows/build-apk.yml pada root repositori.
3. Buka tab Actions di GitHub.
4. Pilih "Build Yanz Android APK", lalu tekan Run workflow.
5. Setelah selesai, buka hasil workflow dan unduh artifact "yanz-debug-apk".
6. Ekstrak artifact; file app-debug.apk adalah APK uji coba.

Workflow belum dapat berjalan sebelum berkas diunggah ke repositori.
APK debug untuk pengujian, bukan rilis Play Store.
